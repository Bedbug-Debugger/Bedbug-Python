DEFAULT_GROUP_NAME = "default_group_name"
